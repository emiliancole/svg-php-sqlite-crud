<?php
$message = ""; 

include("dbSvgConnect.php");

if( isset($_POST['submit_data']) ){

	$id = $_POST['id'];
	$mx = $_POST['mx']; $my = $_POST['my'];
	$x1 = $_POST['x1']; $y1 = $_POST['y1'];
    $x2 = $_POST['x2']; $y2 = $_POST['y2']; 
	$x = $_POST['x']; $y = $_POST['y'];
	$style = $_POST['style'];
    $view = $_POST['view'];
    
	$query = "UPDATE cubic SET mx='$mx', my='$my', x1='$x1', y1='$y1', x2='$x2', y2='$y2',     
    x='$x', y='$y', style='$style',view=$view WHERE rowid=$id";
	
	if( $db->exec($query) ){
		$message = "Data is updated successfully.";
	}else{
		$message = "Sorry, Data is not updated.";
	}
}

$id = $_GET['id']; 

$query = "SELECT * FROM cubic WHERE rowid=$id";
$result = $db->query($query);
$data = $result->fetchArray(); 
?>
	<div style="width:700px;">
		<!-- showing the message here-->
		<div><?= $message;?></div>UPDATE cubic
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<form action="" method="post">
			<input type="hidden" name="id" value="<?= $id;?>">
<tr><td>mx:</td><td><input name="mx" type="text" value="<?= $data['mx'];?>"></td></tr>
<tr><td>my:</td><td><input name="my" type="text" value="<?= $data['my'];?>"></td></tr>
<tr><td>x1:</td><td><input name="x1" type="text" value="<?= $data['x1'];?>"></td></tr>
<tr><td>y1:</td><td><input name="y1" type="text" value="<?= $data['y1'];?>"></td></tr>
<tr><td>x2:</td><td><input name="x2" type="text" value="<?= $data['x2'];?>"></td></tr>
<tr><td>y2:</td><td><input name="y2" type="text" value="<?= $data['y2'];?>"></td></tr>
<tr><td>x:</td><td><input name="x" type="text" value="<?= $data['x'];?>"></td></tr>
<tr><td>y:</td><td><input name="y" type="text" value="<?= $data['y'];?>"></td></tr>
<tr><td>style:</td><td><input name="style" type="text" size="100" value="<?= $data['style'];?>"></td></tr>
<tr><td>view:</td><td><input name="view" type="text" value="<?= $data['view'];?>"></td></tr>
<tr>
				<td>==></td>
				<td><input name="submit_data" type="submit" value="Update Svg Data"></td>
			</tr>
			</form>
		</table>
	</div>
