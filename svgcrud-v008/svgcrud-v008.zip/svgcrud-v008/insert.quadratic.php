<?php
$message = "";
if( isset($_POST['submit_data']) ){

    include("dbSvgConnect.php");

    $mx = $_POST['mx']; $my = $_POST['my'];
    $x1 = $_POST['x1']; $y1 = $_POST['y1'];
    $x = $_POST['x']; $y = $_POST['y'];
	$style = $_POST['style'];
	$view = $_POST['view'];

 $query = "INSERT INTO quadratic (mx,my,x1,y1,x,y,style,view) 
 VALUES ('$mx','$my','$x1','$y1','$x','$y','$style',$view)";

    if( $db->exec($query) ){
        $message = "Svg Data inserted successfully.";
    }else{
        $message = "Sorry, Svg Data is not inserted.";
    }
}

?>
    <div style="width: 700px;">INSERT quadratic
        <!-- showing the message here-->
        <div><?php echo $message;?></div>
        <table width="100%" cellpadding="5" cellspacing="1" border="1">
            <form action="" method="post">
            <tr><td>mx:</td><td><input name="mx" type="text" value="100"></td></tr>
            <tr><td>my:</td><td><input name="my" type="text" value="100"></td></tr>
			<tr><td>x1:</td><td><input name="x1" type="text" value="150"></td></tr>
            <tr><td>y1:</td><td><input name="y1" type="text" value="50"></td></tr>
            <tr><td>x:</td><td><input name="x" type="text" value="200"></td></tr>
            <tr><td>y:</td><td><input name="y" type="text" value="100"></td></tr>
            <tr><td>style:</td><td><input name="style" type="text" size="100"
            value="stroke:black;stroke-width:1;fill:none;"></td></tr>
			<tr><td>view:</td><td><input name="view" type="text" value="0"></td></tr>
            <tr><td>==></td>
            <td><input name="submit_data" type="submit" value="Insert Svg Data"></td>
            </tr>
            </form>
        </table>
    </div>

