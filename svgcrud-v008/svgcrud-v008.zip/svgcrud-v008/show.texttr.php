<?php
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM texttr WHERE view>0";
$result = $db->query($query);

?>
	<div style="width:100%;">texttr		
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
<th>x</th><th>y</th><th>dx</th><th>dy</th><th>style</th>
<th>transform</th><th>content</th><th>view</th>			
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['x'];?></td>
				<td><?= $row['y'];?></td>
				<td><?= $row['dx'];?></td>
				<td><?= $row['dy'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['transform'];?></td>
                <td><?= $row['content'];?></td>
                <td><?= $row['view'];?></td>
			</tr>
			<?php } ?>
		</table>
	</div>
<hr>

<?php
//echo "<svg width='500' height='500' viewBox='0 0 500 500'>";
$querySvg = "SELECT * FROM svg";
$resultSvg = $db->query($querySvg);
$rowSvg = $resultSvg->fetchArray();
	$width=$rowSvg['width']; 
	$height=$rowSvg['height']; 
	$viewBox=$rowSvg['viewBox'];	
	echo  "<svg width='$width' height='$height' viewBox='$viewBox'>";
    
while($row = $result->fetchArray()) {
	$x=$row['x']; $y=$row['y']; $width=$row['width']; $height=$row['height'];
	$dx=$row['dx']; $dy=$row['dy'];
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
    $content=$db->escapeString($row['content']);
	echo  "<text x='$x' y='$y' dx='$dx' dy='$dy' 
    style='$style' transform='$transform' >$content</text>";	
}
echo "</svg>";

?>
<hr>
