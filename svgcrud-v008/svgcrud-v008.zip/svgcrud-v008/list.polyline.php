<?php
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM polyline";
$result = $db->query($query);

?>
	<div style="width:100%;">
		<a href="index.php?shape=insertPolyline">Add New polyline</a>
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<th>points</th>
				<th>style</th>
                <th>view</th>
				<th>Action</th>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['points'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['view'];?></td>
				<td>
					<a href="index.php?shape=updatePolyline&id=<?= $row['rowid'];?>">Edit</a> | 
<a href="index.php?shape=delete&table='polyline'&id=<?= $row['rowid'];?>"
onclick="return confirm('Are you sure to delete id=<?= $row['rowid'];?>?')">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
