<?php
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM arc";
$result = $db->query($query);

?>
	<div style="width:100%;">
		<a href="index.php?shape=insertArc">Add New arc</a>
		<table  width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<th>mx</th><th>my</th>
				<th>rx</th><th>ry</th>
				<th>xar</th><th>laf</th><th>sf</th>
				<th>x</th><th>y</th>
				<th>style</th><th>view</th>
				<th>Action</th>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['mx'];?></td>
				<td><?= $row['my'];?></td>
				<td><?= $row['rx'];?></td>
                <td><?= $row['ry'];?></td>
                <td><?= $row['xar'];?></td>
				<td><?= $row['laf'];?></td>
				<td><?= $row['sf'];?></td>
                <td><?= $row['x'];?></td>
                <td><?= $row['y'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['view'];?></td>
				<td>
					<a href="index.php?shape=updateArc&id=<?= $row['rowid'];?>">Edit</a> | 
<a href="index.php?shape=delete&table='arc'&id=<?= $row['rowid'];?>" 
onclick="return confirm('Are you sure to delete id=<?= $row['rowid'];?>?')">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
