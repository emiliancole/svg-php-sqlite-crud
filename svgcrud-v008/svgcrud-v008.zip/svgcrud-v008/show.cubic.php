<?php
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM cubic WHERE view>0";
$result = $db->query($query);

?>
	<div style="width:100%;">cubic		
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr><th>mx</th><th>my</th><th>x1</th><th>y1</th>
            <th>x2</th><th>y2</th><th>x</th><th>y</th>
            <th>style</th><th>view</th>
            </tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['mx'];?></td>
                <td><?= $row['my'];?></td>
                <td><?= $row['x1'];?></td>
                <td><?= $row['y1'];?></td>
                <td><?= $row['x2'];?></td>
                <td><?= $row['y2'];?></td>
                <td><?= $row['x'];?></td>
                <td><?= $row['y'];?></td>
				<td><?= $row['style'];?></td>	
                <td><?= $row['view'];?></td>
			</tr>
			<?php } ?>
		</table>
	</div>
<hr>

<?php
//echo "<svg width='500' height='500' viewBox='0 0 500 500'>";
$querySvg = "SELECT * FROM svg";
$resultSvg = $db->query($querySvg);
$rowSvg = $resultSvg->fetchArray();
	$width=$rowSvg['width']; 
	$height=$rowSvg['height']; 
	$viewBox=$rowSvg['viewBox'];	
	echo  "<svg width='$width' height='$height' viewBox='$viewBox'>";
    
while($row = $result->fetchArray()) {
	$mx=$row['mx']; $my=$row['my']; 
    $x1=$row['x1']; $y1=$row['y1'];
    $x2=$row['x2']; $y2=$row['y2']; 
    $x=$row['x']; $y=$row['y'];
	$style=$db->escapeString($row['style']);	
echo  "<path d='M $mx $my C $x1 $y1 $x2 $y2 $x $y' style='$style' />";	
}
echo "</svg>";

?>
<hr>
