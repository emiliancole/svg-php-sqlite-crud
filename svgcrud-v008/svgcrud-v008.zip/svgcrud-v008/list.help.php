<?php
include("dbSvgConnect.php");

$query = "SELECT * FROM help ORDER BY keyword";
$result = $db->query($query);
?>
<div style="width:100%;">svgSqlite Help
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<th>keyword</th>
				<th>description</th>
				<th>value</th>
				<th>example</th>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['keyword'];?></td>
				<td><?= $row['description'];?></td>
				<td><?= $row['value'];?></td>
				<td><?= $row['example'];?></td>
			</tr>
			<?php } ?>
		</table>
	</div>
