<?php
$message = ""; 

include("dbSvgConnect.php");

if( isset($_POST['submit_data']) ){

	$id = $_POST['id'];
	$mx = $_POST['mx']; $my = $_POST['my'];
	$rx = $_POST['rx']; $ry = $_POST['ry'];
    $xar = $_POST['xar']; $laf = $_POST['laf']; $sf = $_POST['sf'];
	$x = $_POST['x']; $y = $_POST['y'];
	$style = $_POST['style'];
    $view = $_POST['view'];
    
	$query = "UPDATE arc SET mx='$mx', my='$my', rx='$rx', ry='$ry', xar='$xar', laf='$laf', sf='$sf',     
    x='$x', y='$y', style='$style',view=$view WHERE rowid=$id";
	
	if( $db->exec($query) ){
		$message = "Data is updated successfully.";
	}else{
		$message = "Sorry, Data is not updated.";
	}
}

$id = $_GET['id']; 

$query = "SELECT * FROM arc WHERE rowid=$id";
$result = $db->query($query);
$data = $result->fetchArray(); 
?>
	<div style="width:700px;">
		<!-- showing the message here-->
		<div><?= $message;?></div>UPDATE arc
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<form action="" method="post">
			<input type="hidden" name="id" value="<?= $id;?>">
<tr><td>mx:</td><td><input name="mx" type="text" value="<?= $data['mx'];?>"></td></tr>
<tr><td>my:</td><td><input name="my" type="text" value="<?= $data['my'];?>"></td></tr>
<tr><td>rx:</td><td><input name="rx" type="text" value="<?= $data['rx'];?>"></td></tr>
<tr><td>ry:</td><td><input name="ry" type="text" value="<?= $data['ry'];?>"></td></tr>
<tr><td>xar:</td><td><input name="xar" type="text" value="<?= $data['xar'];?>"></td></tr>
<tr><td>laf:</td><td><input name="laf" type="text" value="<?= $data['laf'];?>"></td></tr>
<tr><td>sf:</td><td><input name="sf" type="text" value="<?= $data['sf'];?>"></td></tr>
<tr><td>x:</td><td><input name="x" type="text" value="<?= $data['x'];?>"></td></tr>
<tr><td>y:</td><td><input name="y" type="text" value="<?= $data['y'];?>"></td></tr>
<tr><td>style:</td><td><input name="style" type="text" size="100" value="<?= $data['style'];?>"></td></tr>
<tr><td>view:</td><td><input name="view" type="text" value="<?= $data['view'];?>"></td></tr>
<tr>
				<td>==></td>
				<td><input name="submit_data" type="submit" value="Update Svg Data"></td>
			</tr>
			</form>
		</table>
	</div>
