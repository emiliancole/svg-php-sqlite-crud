<?php
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM svg";
$result = $db->query($query);

?>
	<div style="width:100%;">viewBox
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<th>width</th>
                <th>height</th>
                <th>viewBox</th>
				<th>Action</th>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['width'];?></td>
                <td><?= $row['height'];?></td>
                <td><?= $row['viewBox'];?></td>
				<td>
					<a href="index.php?shape=updateViewBox&id=<?= $row['rowid'];?>">Edit</a> 
					
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
