<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="generator" content="AlterVista - Editor HTML"/>
  <link rel="stylesheet" type="text/css" href="aaa.style.css" />
  <title>svgSqlite-v008</title>
</head>
<body>

<header>
<h4>Svg-php-sqlite v008</h4>
<p><a href="index.php">Home</a> | 
<a href="index.php?shape=viewBox">viewBox</a> |
<a href="index.php?shape=showTables">ShowTables</a> |
<a href="index.php?shape=showSvg1">Svg1</a> | 
<a href="index.php?shape=sqlSelect">Select</a> |
<a href="index.php?shape=sqlSelectTable">SelectTable</a> | 
<a href="index.php?shape=sqlSelectView">SelectView</a> | 
<a href="svg.showCoords.php" target="_blank">Coords</a> | 
<a href="index.php?shape=help">Help</a> |
</header>

<section>
  <nav>
    <ul>
      <li><a href="index.php?shape=arc">arc</a> | 
      <a href="index.php?shape=showArc">show</a></li>
      <li><a href="index.php?shape=circle">circle</a> | 
      <a href="index.php?shape=showCircle">show</a></li>
      <li><a href="index.php?shape=circletr">circletr</a> | 
      <a href="index.php?shape=showCircletr">show</a></li>
      <li><a href="index.php?shape=cubic">cubic</a> | 
      <a href="index.php?shape=showCubic">show</a></li>
      <li><a href="index.php?shape=ellipse">ellipse</a> | 
      <a href="index.php?shape=showEllipse">show</a></li>
      <li><a href="index.php?shape=ellipsetr">ellipsetr</a> | 
      <a href="index.php?shape=showEllipsetr">show</a></li>
      <li><a href="index.php?shape=image">image</a> | 
      <a href="index.php?shape=showImage">show</a></li>
      <li><a href="index.php?shape=imagetr">imagetr</a> | 
      <a href="index.php?shape=showImagetr">show</a></li>    
      <li><a href="index.php?shape=line">line</a> | 
      <a href="index.php?shape=showLine">show</a></li>
      <li><a href="index.php?shape=linetr">linetr</a> | 
      <a href="index.php?shape=showLinetr">show</a></li>
      <li><a href="index.php?shape=path">path</a> | 
      <a href="index.php?shape=showPath">show</a></li>
      <li><a href="index.php?shape=pathtr">pathtr</a> | 
      <a href="index.php?shape=showPathtr">show</a></li>
      <li><a href="index.php?shape=polygon">polygon</a> | 
      <a href="index.php?shape=showPolygon">show</a></li>
      <li><a href="index.php?shape=polygontr">polygontr</a> | 
      <a href="index.php?shape=showPolygontr">show</a></li>
      <li><a href="index.php?shape=polyline">polyline</a> | 
      <a href="index.php?shape=showPolyline">show</a></li>
      <li><a href="index.php?shape=polylinetr">polylinetr</a> | 
      <a href="index.php?shape=showPolylinetr">show</a></li>
      <li><a href="index.php?shape=quadratic">quadratic</a> | 
      <a href="index.php?shape=showQuadratic">show</a></li>     
      <li><a href="index.php?shape=rect">rect</a> | 
      <a href="index.php?shape=showRect">show</a></li>
      <li><a href="index.php?shape=recttr">recttr</a> | 
      <a href="index.php?shape=showRecttr">show</a></li>
      <li><a href="index.php?shape=text">text</a> | 
      <a href="index.php?shape=showText">show</a></li>
      <li><a href="index.php?shape=texttr">texttr</a> | 
      <a href="index.php?shape=showTexttr">show</a></li>
    </ul>
  </nav>
  
  <article>
  
<?php 
$shape=$_GET['shape'];

switch ($shape) {
	case 'delete':
		include("delete.php");
        break;
	case 'showTables':
		include("show.tables.php");
        break;
    case 'showSvg1':
		include("show.svg1.php");
        break;
    case 'sqlSelect':
		include("sql.select.php");
        break;
    case 'sqlSelectTable':
		include("sql.select.table.php");
        break;
    case 'sqlSelectView':
		include("sql.select.view.php");
        break;
    case 'help':
		include("list.help.php");
        break;
//SHAPES
	case 'arc':
		include("list.arc.php");
        break;
    case 'showArc':
		include("show.arc.php");
        break;
    case 'insertArc':
		include("insert.arc.php");
        break;
    case 'updateArc':
		include("update.arc.php");
        break;
    case 'circle':
		include("list.circle.php");
        break;
    case 'showCircle':
		include("show.circle.php");
        break;
    case 'insertCircle':
		include("insert.circle.php");
        break;
    case 'updateCircle':
		include("update.circle.php");
        break;
    case 'circletr':
		include("list.circletr.php");
        break;
    case 'showCircletr':
		include("show.circletr.php");
        break;
    case 'insertCircletr':
		include("insert.circletr.php");
        break;
    case 'updateCircletr':
		include("update.circletr.php");
        break;
    case 'cubic':
		include("list.cubic.php");
        break;
    case 'showCubic':
		include("show.cubic.php");
        break;
    case 'insertCubic':
		include("insert.cubic.php");
        break;
    case 'updateCubic':
		include("update.cubic.php");
        break;
    case 'ellipse':
		include("list.ellipse.php");
        break;
    case 'showEllipse':
		include("show.ellipse.php");
        break;
    case 'insertEllipse':
		include("insert.ellipse.php");
        break;
    case 'updateEllipse':
		include("update.ellipse.php");
        break;
    case 'ellipsetr':
		include("list.ellipsetr.php");
        break;
    case 'showEllipsetr':
		include("show.ellipsetr.php");
        break;
    case 'insertEllipsetr':
		include("insert.ellipsetr.php");
        break;
    case 'updateEllipsetr':
		include("update.ellipsetr.php");
        break;
    case 'image':
		include("list.image.php");
        break;
    case 'showImage':
		include("show.image.php");
        break;
    case 'insertImage':
		include("insert.image.php");
        break;
    case 'updateImage':
		include("update.image.php");
        break;
    case 'imagetr':
		include("list.imagetr.php");
        break;
    case 'showImagetr':
		include("show.imagetr.php");
        break;
    case 'insertImagetr':
		include("insert.imagetr.php");
        break;
    case 'updateImagetr':
		include("update.imagetr.php");
        break;
    case 'line':
        include("list.line.php");
        break;
    case 'showLine':
        include("show.line.php");
        break;
    case 'insertLine':
		include("insert.line.php");
        break;
    case 'updateLine':
		include("update.line.php");
        break;
    case 'linetr':
        include("list.linetr.php");
        break;
    case 'showLinetr':
        include("show.linetr.php");
        break;
    case 'insertLinetr':
		include("insert.linetr.php");
        break;
    case 'updateLinetr':
		include("update.linetr.php");
        break;
    case 'path':
        include("list.path.php");
        break;
    case 'showPath':
        include("show.path.php");
        break;
    case 'insertPath':
		include("insert.path.php");
        break;
    case 'updatePath':
		include("update.path.php");
        break;
    case 'pathtr':
        include("list.pathtr.php");
        break;
    case 'showPathtr':
        include("show.pathtr.php");
        break;
    case 'insertPathtr':
		include("insert.pathtr.php");
        break;
    case 'updatePathtr':
		include("update.pathtr.php");
        break;
    case 'polygon':
        include("list.polygon.php");
        break;
    case 'showPolygon':
        include("show.polygon.php");
        break;
    case 'insertPolygon':
		include("insert.polygon.php");
        break;
    case 'updatePolygon':
		include("update.polygon.php");
        break;
    case 'polygontr':
        include("list.polygontr.php");
        break;
    case 'showPolygontr':
        include("show.polygontr.php");
        break;
    case 'insertPolygontr':
		include("insert.polygontr.php");
        break;
    case 'updatePolygontr':
		include("update.polygontr.php");
        break;
    case 'polyline':
        include("list.polyline.php");
        break;
    case 'showPolyline':
        include("show.polyline.php");
        break;
    case 'insertPolyline':
		include("insert.polyline.php");
        break;
    case 'updatePolyline':
		include("update.polyline.php");
        break;
    case 'polylinetr':
        include("list.polylinetr.php");
        break;
    case 'showPolylinetr':
        include("show.polylinetr.php");
        break;
    case 'insertPolylinetr':
		include("insert.polylinetr.php");
        break;
    case 'updatePolylinetr':
		include("update.polylinetr.php");
        break;
    case 'quadratic':
        include("list.quadratic.php");
        break;
    case 'showQuadratic':
        include("show.quadratic.php");
        break;
    case 'insertQuadratic':
		include("insert.quadratic.php");
        break;
    case 'updateQuadratic':
		include("update.quadratic.php");
        break;
    case 'rect':
        include("list.rect.php");
        break;
    case 'showRect':
        include("show.rect.php");
        break;
    case 'insertRect':
		include("insert.rect.php");
        break;
    case 'updateRect':
		include("update.rect.php");
        break;
    case 'recttr':
        include("list.recttr.php");
        break;
    case 'showRecttr':
        include("show.recttr.php");
        break;
    case 'insertRecttr':
		include("insert.recttr.php");
        break;
    case 'updateRecttr':
		include("update.recttr.php");
        break;
    case 'text':
        include("list.text.php");
        break;
    case 'showText':
        include("show.text.php");
        break;
    case 'insertText':
		include("insert.text.php");
        break;
    case 'updateText':
		include("update.text.php");
        break;
    case 'texttr':
        include("list.texttr.php");
        break;
    case 'showTexttr':
        include("show.texttr.php");
        break;
    case 'insertTexttr':
		include("insert.texttr.php");
        break;
    case 'updateTexttr':
		include("update.texttr.php");
        break;
        
    case 'viewBox':
        include("list.viewbox.php");
        break; 
    case 'showViewBox':
        include("show.viewbox.php");
        break;
    case 'insertViewBox':
		include("insert.viewbox.php");
        break;
    case 'updateViewBox':
		include("update.viewbox.php");
        break;
	default:
       echo "<h1>select a shape</h1>";
}

?>
 </article>
</section>

</body>
</html>
