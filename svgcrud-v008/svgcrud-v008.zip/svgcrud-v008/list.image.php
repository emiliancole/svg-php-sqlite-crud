<?php
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM image";
$result = $db->query($query);

?>
	<div style="width:100%;">
		<a href="index.php?shape=insertImage">Add New image</a>
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<th>x</th>
				<th>y</th>
				<th>width</th>
                <th>height</th>
                <th>href</th>
				<th>view</th>
				<th>Action</th>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['x'];?></td>
				<td><?= $row['y'];?></td>
				<td><?= $row['width'];?></td>
                <td><?= $row['height'];?></td>
                <td><?= $row['href'];?></td>
				<td><?= $row['view'];?></td>
				<td>
					<a href="index.php?shape=updateImage&id=<?= $row['rowid'];?>">Edit</a> | 
<a href="index.php?shape=delete&table='image'&id=<?= $row['rowid'];?>"
onclick="return confirm('Are you sure to delete id=<?= $row['rowid'];?>?')">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
