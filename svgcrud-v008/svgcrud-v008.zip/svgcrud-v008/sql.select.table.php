<?php

$database_name = "svgSqlite.db";
$db = new SQLite3($database_name);

if ( !isset($_POST['submit_data']) ) {
  $table=''; $whereTable = 1; }
else {
$table=$_POST['table'];
$whereTable=$_POST['whereTable'];
}

$queryTable = "SELECT * FROM $table WHERE $whereTable";

$resultTable = $db->query($queryTable);

?>
<div>SELECT * FROM tablename WHERE conditions
<table width="100%" cellpadding="5" cellspacing="1" border="1">
<form action="" method="post" >
<tr><td>SELECT * FROM 
<input name="table" type="text" placeholder="circle" 
value="<?= $table; ?>"> WHERE </td>
<td><input name="whereTable" type="text" size="100" placeholder="1" 
value="<?= $whereTable; ?>"></td></tr>

<tr><td>==> Enter tablename and conditions ==></td>
<td><input name="submit_data" type="submit" value="Select Svg table Query"></td>
</tr>
</form>
</table>
</div>
<?php

$querySvg = "SELECT * FROM svg";
$resultSvg = $db->query($querySvg);
$rowSvg = $resultSvg->fetchArray();
	$width=$rowSvg['width']; 
	$height=$rowSvg['height']; 
	$viewBox=$rowSvg['viewBox'];	
	echo  "<svg width='$width' height='$height' viewBox='$viewBox'>";	
   
switch ($table) {   
case 'image':
while($row = $resultTable->fetchArray()) {
	$x=$row['x']; $y=$row['y']; $width=$row['width']; $height=$row['height'];
	$href=$row['href']; 	
	echo  "<image x='$x' y='$y' width='$width' height='$height' xlink:href='$href' />";	
}
break;
case 'circle':
while($row = $resultTable->fetchArray()) {
	$cx=$row['cx']; $cy=$row['cy'];
	$r=$row['r']; 
	$style=$db->escapeString($row['style']);	
	echo  "<circle cx='$cx' cy='$cy' r='$r' style='$style' />";
}
break;
case 'circletr':
while($row = $resultTable->fetchArray()) {
	$cx=$row['cx']; $cy=$row['cy'];
	$r=$row['r']; 
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
	echo  "<circle cx='$cx' cy='$cy' r='$r' style='$style' transform='$transform' />";
}
break;
case 'ellipse':
while($row = $resultTable->fetchArray()) {
	$cx=$row['cx']; $cy=$row['cy'];
	$rx=$row['rx']; $ry=$row['ry'];
	$style=$db->escapeString($row['style']);	
	echo  "<ellipse cx='$cx' cy='$cy' rx='$rx' ry='$ry' style='$style' />";
}
break;
case 'ellipsetr':
while($row = $resultTable->fetchArray()) {
	$cx=$row['cx']; $cy=$row['cy'];
	$rx=$row['rx']; $ry=$row['ry'];
	$style=$db->escapeString($row['style']);	
    $transform=$db->escapeString($row['transform']);
	echo  "<ellipse cx='$cx' cy='$cy' rx='$rx' ry='$ry' style='$style' transform='$transform' />";
}
break;
case 'path':
while($row = $resultTable->fetchArray()) {
	$d=$row['d']; 
	$style=$db->escapeString($row['style']);	
echo  "<path d='$d' style='$style' />";	
}
break;
case 'arc':   
while($row = $resultTable->fetchArray()) {
$mx=$row['mx']; $my=$row['my']; $rx=$row['rx']; $ry=$row['ry'];
$xar=$row['xar']; $laf=$row['laf']; $sf=$row['sf']; 
$x=$row['x']; $y=$row['y'];
$style=$db->escapeString($row['style']);	
echo  "<path d='M $mx $my A $rx $ry $xar $laf $sf $x $y' style='$style' />";
	}
break;
case 'cubic':   
while($row = $resultTable->fetchArray()) {
$mx=$row['mx']; $my=$row['my']; $x1=$row['x1']; $y1=$row['y1'];
$x2=$row['x2']; $y2=$row['y2']; 
$x=$row['x']; $y=$row['y'];
$style=$db->escapeString($row['style']);	
echo  "<path d='M $mx $my C $x1 $y1 $x2 $y2 $x $y' style='$style' />";
	}
break;
case 'quadratic':   
while($row = $resultTable->fetchArray()) {
$mx=$row['mx']; $my=$row['my']; $x1=$row['x1']; $y1=$row['y1'];
$x=$row['x']; $y=$row['y'];
$style=$db->escapeString($row['style']);	
echo  "<path d='M $mx $my Q $x1 $y1 $x $y' style='$style' />";
	}
break;
case 'pathtr':
while($row = $resultTable->fetchArray()) {
	$d=$row['d']; 
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
echo  "<path d='$d' style='$style' transform='$transform' />";	
}
break;
case 'polygon':
while($row = $resultTable->fetchArray()) {
	$points=$row['points']; 
	$style=$db->escapeString($row['style']);	
echo  "<polygon points='$points' style='$style' />";	
}
break;
case 'polygontr':
while($row = $resultTable->fetchArray()) {
	$points=$row['points']; 
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
echo  "<polygon points='$points' style='$style' transform='$transform' />";	
}
break;
case 'polyline':
while($row = $resultTable->fetchArray()) {
	$points=$row['points']; 
	$style=$db->escapeString($row['style']);	
echo  "<polyline points='$points' style='$style' />";	
}
break;
case 'polylinetr':
while($row = $resultTable->fetchArray()) {
	$points=$row['points']; 
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
echo  "<polyline points='$points' style='$style' transform='$transform'/>";	
}
break;
case 'rect':
while($row = $resultTable->fetchArray()) {
	$x=$row['x']; $y=$row['y']; $width=$row['width']; $height=$row['height'];
	$rx=$row['rx']; $ry=$row['ry'];
	$style=$db->escapeString($row['style']);	
	echo  "<rect x='$x' y='$y' width='$width' height='$height' rx='$rx' ry='$ry' style='$style' />";	
}
break;
case 'recttr':
while($row = $resultTable->fetchArray()) {
	$x=$row['x']; $y=$row['y']; $width=$row['width']; $height=$row['height'];
	$rx=$row['rx']; $ry=$row['ry'];
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
	echo  "<rect x='$x' y='$y' width='$width' height='$height' rx='$rx' ry='$ry' 
    style='$style' transform='$transform' />";	
}
break;
case 'line':
while($row = $resultTable->fetchArray()) {
	$x1=$row['x1']; $y1=$row['y1']; $x2=$row['x2']; $y2=$row['y2'];
	$style=$db->escapeString($row['style']);	
	echo  "<line x1='$x1' y1='$y1' x2='$x2' y2='$y2' style='$style' />";	
}
break;
case 'linetr':
while($row = $resultTable->fetchArray()) {
	$x1=$row['x1']; $y1=$row['y1']; $x2=$row['x2']; $y2=$row['y2'];
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
	echo  "<line x1='$x1' y1='$y1' x2='$x2' y2='$y2' style='$style' transform='$transform' />";	
}
break;
case 'text':
while($row = $resultTable->fetchArray()) {
	$x=$row['x']; $y=$row['y']; $width=$row['width']; $height=$row['height'];
	$dx=$row['dx']; $dy=$row['dy'];
	$style=$db->escapeString($row['style']);
    $content=$db->escapeString($row['content']);
	echo  "<text x='$x' y='$y' dx='$dx' dy='$dy' style='$style' >$content</text>";	
}
break;
case 'texttr':
while($row = $resultTable->fetchArray()) {
	$x=$row['x']; $y=$row['y']; $width=$row['width']; $height=$row['height'];
	$dx=$row['dx']; $dy=$row['dy'];
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
    $content=$db->escapeString($row['content']);
	echo  "<text x='$x' y='$y' dx='$dx' dy='$dy' 
    style='$style' transform='$transform' >$content</text>";	
}
break;
case 'imagetr':
while($row = $resultTable->fetchArray()) {
	$x=$row['x']; $y=$row['y']; $width=$row['width']; $height=$row['height'];
	$href=$row['href']; 
	$transform=$db->escapeString($row['transform']);	
	echo  "<image x='$x' y='$y' width='$width' height='$height' xlink:href='$href' transform='$transform' />";	
}
break;
} //END SWITCH
echo "</svg>";
echo "<hr>";
?>
