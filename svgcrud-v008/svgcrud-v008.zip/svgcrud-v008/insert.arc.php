<?php
$message = "";
if( isset($_POST['submit_data']) ){

    include("dbSvgConnect.php");

    $mx = $_POST['mx']; $my = $_POST['my'];
    $rx = $_POST['rx']; $ry = $_POST['ry'];
    $xar = $_POST['xar']; $laf = $_POST['laf']; $sf = $_POST['sf'];
    $x = $_POST['x']; $y = $_POST['y'];
	$style = $_POST['style'];
	$view = $_POST['view'];

 $query = "INSERT INTO arc (mx,my,rx,ry,xar,laf,sf,x,y,style,view) 
 VALUES ('$mx','$my','$rx','$ry','$xar','$laf','$sf','$x','$y','$style',$view)";

    if( $db->exec($query) ){
        $message = "Svg Data inserted successfully.";
    }else{
        $message = "Sorry, Svg Data is not inserted.";
    }
}

?>
    <div style="width: 700px;">INSERT arc
        <!-- showing the message here-->
        <div><?php echo $message;?></div>
        <table width="100%" cellpadding="5" cellspacing="1" border="1">
            <form action="" method="post">
            <tr><td>mx:</td><td><input name="mx" type="text" value="100"></td></tr>
            <tr><td>my:</td><td><input name="my" type="text" value="100"></td></tr>
			<tr><td>rx:</td><td><input name="rx" type="text" value="100"></td></tr>
            <tr><td>ry:</td><td><input name="ry" type="text" value="50"></td></tr>
            <tr><td>xar:</td><td><input name="xar" type="text" value="0"></td></tr>
            <tr><td>laf:</td><td><input name="laf" type="text" value="0"></td></tr>
            <tr><td>sf:</td><td><input name="sf" type="text" value="1"></td></tr>
            <tr><td>x:</td><td><input name="x" type="text" value="150"></td></tr>
            <tr><td>y:</td><td><input name="y" type="text" value="200"></td></tr>
            <tr><td>style:</td><td><input name="style" type="text" size="100"
            value="stroke:black;stroke-width:1;fill:none;"></td></tr>
			<tr><td>view:</td><td><input name="view" type="text" value="0"></td></tr>
            <tr><td>==></td>
            <td><input name="submit_data" type="submit" value="Insert Svg Data"></td>
            </tr>
            </form>
        </table>
    </div>

