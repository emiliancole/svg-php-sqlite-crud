<?php
include("dbSvgConnect.php");

$table = $_GET['table'];
$id = $_GET['id'];

$query = "DELETE FROM $table WHERE rowid=$id";

if( $db->query($query) ){
	$message = "Record is deleted successfully.";
}else {
	$message = "Sorry, Record is not deleted.";
}
echo $message;
?>


