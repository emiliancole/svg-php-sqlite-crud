<?php
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM line";
$result = $db->query($query);

?>
	<div style="width:100%;">
		<a href="index.php?shape=insertLine">Add New line</a>
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<th>x1</th><th>y1</th>
				<th>x2</th><th>y2</th>
				<th>style</th><th>view</th>
				<th>Action</th>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['x1'];?></td>
				<td><?= $row['y1'];?></td>
				<td><?= $row['x2'];?></td>
                <td><?= $row['y2'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['view'];?></td>
				<td>
					<a href="index.php?shape=updateLine&id=<?= $row['rowid'];?>">Edit</a> | 
<a href="index.php?shape=delete&table='line'&id=<?= $row['rowid'];?>"
onclick="return confirm('Are you sure to delete id=<?= $row['rowid'];?>?')">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
