<?php
$message = "";
if( isset($_POST['submit_data']) ){

    include("dbSvgConnect.php");

    $points = $_POST['points']; 
	$style = $_POST['style'];
    $transform = $_POST['transform'];
	$view = $_POST['view'];

 $query = "INSERT INTO polylinetr (points,style,transform,view) VALUES ('$points','$style','$transform',$view)";

    if( $db->exec($query) ){
        $message = "Svg Data inserted successfully.";
    }else{
        $message = "Sorry, Svg Data is not inserted.";
    }
}

?>
    <div style="width:700px;">INSERT polylinetr
        <!-- showing the message here-->
        <div><?= $message;?></div>
        <table width="100%" cellpadding="5" cellspacing="1" border="1">
            <form action="" method="post">
            <tr><td>points:</td><td><input name="points" type="text" 
            value="0,100 50,25 50,75 100,0" size="100"></td></tr>
            <tr><td>style:</td><td><input name="style" type="text" size="100"
            value="stroke:black;stroke-width:1;fill:none;"></td></tr>
            <tr><td>transform:</td><td><input name="transform" type="text" size="100"
            value="rotate(0 0 0)"></td></tr>
			<tr><td>view:</td><td><input name="view" type="text" 
            value="0"></td></tr>
            <tr><td>==></td>
            <td><input name="submit_data" type="submit" value="Insert Svg Data"></td>
            </tr>
            </form>
        </table>
    </div>

