<?php
$database_name = "svgSqlite.db";
$db = new SQLite3($database_name);
/**
// Create Table "circle" into Database if not exists
$query = "CREATE TABLE IF NOT EXISTS circle (cx STRING,cy STRING,r STRING,style STRING)";
$db->exec($query);
*/
?>

