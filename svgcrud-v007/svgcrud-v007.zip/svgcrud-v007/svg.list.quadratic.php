<?php
include("index.html");
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM quadratic";
$result = $db->query($query);

?>
	<div style="width: 700px; margin: 20px auto;">
		<a href="svg.insert.quadratic.php">Add New quadratic</a>
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<td>mx</td><td>my</td>
				<td>x1</td><td>y1</td>
				<td>x</td><td>y</td>
				<td>style</td><td>view</td>
				<td>Action</td>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['mx'];?></td>
				<td><?= $row['my'];?></td>
				<td><?= $row['x1'];?></td>
                <td><?= $row['y1'];?></td>
                <td><?= $row['x'];?></td>
                <td><?= $row['y'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['view'];?></td>
				<td>
					<a href="svg.update.quadratic.php?id=<?= $row['rowid'];?>">Edit</a> | 
					<a href="svg.delete.php?table='quadratic'&id=<?= $row['rowid'];?>">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
</body>
</html>