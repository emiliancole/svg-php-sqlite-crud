<?php
include("index.html");
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM arc";
$result = $db->query($query);

?>
	<div style="width: 700px; margin: 20px auto;">
		<a href="svg.insert.arc.php">Add New arc</a>
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<td>mx</td><td>my</td>
				<td>rx</td><td>ry</td>
				<td>xar</td><td>laf</td><td>sf</td>
				<td>x</td><td>y</td>
				<td>style</td><td>view</td>
				<td>Action</td>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['mx'];?></td>
				<td><?= $row['my'];?></td>
				<td><?= $row['rx'];?></td>
                <td><?= $row['ry'];?></td>
                <td><?= $row['xar'];?></td>
				<td><?= $row['laf'];?></td>
				<td><?= $row['sf'];?></td>
                <td><?= $row['x'];?></td>
                <td><?= $row['y'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['view'];?></td>
				<td>
					<a href="svg.update.arc.php?id=<?= $row['rowid'];?>">Edit</a> | 
					<a href="svg.delete.php?table='arc'&id=<?= $row['rowid'];?>">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
</body>
</html>