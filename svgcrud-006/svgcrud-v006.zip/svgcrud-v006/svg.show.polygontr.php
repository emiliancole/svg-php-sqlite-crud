<?php
include("index.html");
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM polygontr WHERE view>0";
$result = $db->query($query);

?>
	<div style="width:700px; margin: 20px auto;">polygontr		
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr><td>points</td><td>style</td>
            <td>transform</td><td>view</td></tr>
            
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['points'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['transform'];?></td>
                <td><?= $row['view'];?></td>
			</tr>
			<?php } ?>
		</table>
	</div>
<hr>

<?php
//echo "<svg width='500' height='500' viewBox='0 0 500 500'>";
$querySvg = "SELECT * FROM svg";
$resultSvg = $db->query($querySvg);
$rowSvg = $resultSvg->fetchArray();
	$width=$rowSvg['width']; 
	$height=$rowSvg['height']; 
	$viewBox=$rowSvg['viewBox'];	
	echo  "<svg width='$width' height='$height' viewBox='$viewBox'>";
    
while($row = $result->fetchArray()) {
	$points=$row['points']; 
	$style=$db->escapeString($row['style']);
    $transform=$db->escapeString($row['transform']);
echo  "<polygon points='$points' style='$style' transform='$transform' />";	
}
echo "</svg>";

?>
<hr>
</body>
</html>