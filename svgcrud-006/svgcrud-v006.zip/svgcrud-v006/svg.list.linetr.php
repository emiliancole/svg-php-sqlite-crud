<?php
include("index.html");
include("dbSvgConnect.php");

$query = "SELECT rowid, * FROM linetr";
$result = $db->query($query);

?>
	<div style="width: 700px; margin: 20px auto;">
		<a href="svg.insert.line.php">Add New linetr</a>
		<table width="100%" cellpadding="5" cellspacing="1" border="1">
			<tr>
				<td>x1</td><td>y1</td>
				<td>x2</td><td>y2</td>
				<td>style</td>
                <td>transform</td>
                <td>view</td>
				<td>Action</td>
			</tr>
			<?php while($row = $result->fetchArray()) {?>
			<tr>
				<td><?= $row['x1'];?></td>
				<td><?= $row['y1'];?></td>
				<td><?= $row['x2'];?></td>
                <td><?= $row['y2'];?></td>
				<td><?= $row['style'];?></td>
                <td><?= $row['transform'];?></td>
                <td><?= $row['view'];?></td>
				<td>
					<a href="svg.update.linetr.php?id=<?= $row['rowid'];?>">Edit</a> | 
					<a href="svg.delete.linetr.php?id=<?= $row['rowid'];?>">Delete</a>
				</td>
			</tr>
			<?php } ?>
		</table>
	</div>
</body>
</html>