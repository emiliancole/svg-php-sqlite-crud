<?php
include("index.html");
include("dbSvgConnect.php");

$id = $_GET['id']; 

$query = "DELETE FROM polylinetr WHERE rowid=$id";

if( $db->query($query) ){
	$message = "Record is deleted successfully.";
}else {
	$message = "Sorry, Record is not deleted.";
}
echo $message;
?>


